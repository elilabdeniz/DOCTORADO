En typed-iswim.rkt esta el modelo redex de ISWIM
.test-basic-types.rkt, algunos test para el sistema de tipos, incluyendo call cc
.randomized-type-test.rkt, los test de soundness
